create function nextval(seq_name varchar(50)) returns varchar(50)
BEGIN
DECLARE seq VARCHAR(50); 
SET seq = CONCAT(date_format(sysdate(),'%Y%m%d'),seq_name);
UPDATE ksys_liusdy
SET dangqzh = dangqzh + buchang 
WHERE liusbm = seq; 
RETURN CONCAT(date_format(sysdate(),'%Y%m%d'),LPAD(currval(seq),8,'0')); 
END;

