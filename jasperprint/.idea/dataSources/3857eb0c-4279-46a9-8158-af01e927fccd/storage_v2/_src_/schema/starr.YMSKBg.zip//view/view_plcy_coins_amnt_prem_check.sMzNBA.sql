create view view_plcy_coins_amnt_prem_check as select `t`.`c_appl_no`                                                       AS `c_appl_no`,
                                                      `t`.`c_endr_no`                                                       AS `c_endr_no`,
                                                      `t`.`n_endr_tms`                                                      AS `n_endr_tms`,
                                                      ((`t`.`n_amnt` * `t1`.`n_coins_share`) - `t1`.`n_coins_amnt`)         AS `diffamnt`,
                                                      ((`t`.`n_prem` * `t1`.`n_coins_share`) - `t1`.`n_coins_prem`)         AS `diffprem`,
                                                      ((`t`.`n_notax_prem` * `t1`.`n_coins_share`) -
                                                       `t1`.`n_coins_notax_prem`)                                           AS `diffnotaxprem`,
                                                      ((`t`.`n_vat_amnt` * `t1`.`n_coins_share`) - `t1`.`n_coins_vat_amnt`) AS `diffvat`,
                                                      `t`.`n_amnt`                                                          AS `n_amnt`,
                                                      `t1`.`n_coins_amnt`                                                   AS `n_coins_amnt`,
                                                      `t`.`n_prem`                                                          AS `n_prem`,
                                                      `t1`.`n_coins_prem`                                                   AS `n_coins_prem`,
                                                      `t`.`n_notax_prem`                                                    AS `n_notax_prem`,
                                                      `t1`.`n_coins_share`                                                  AS `n_coins_share`,
                                                      `t1`.`n_coins_notax_prem`                                             AS `n_coins_notax_prem`,
                                                      `t`.`n_vat_amnt`                                                      AS `n_vat_amnt`,
                                                      `t1`.`n_coins_vat_amnt`                                               AS `n_coins_vat_amnt`,
                                                      `t`.`c_biz_type`                                                      AS `c_biz_type`,
                                                      `t`.`c_plcy_sts`                                                      AS `c_plcy_sts`,
                                                      `t`.`d_crtr_time`                                                     AS `d_crtr_time`,
                                                      (select `s`.`c_cname`
                                                       from `starr`.`tb_base_comm_code` `s`
                                                       where (`s`.`c_code` = `t`.`c_coins_type`))                           AS `Name_exp_20`,
                                                      `t`.`c_renew_mark`                                                    AS `c_renew_mark`,
                                                      `t`.`d_uptr_time`                                                     AS `d_uptr_time`,
                                                      (case
                                                         when (
                                                             abs(((`t`.`n_amnt` * `t1`.`n_coins_share`) - `t1`.`n_coins_amnt`)) >
                                                             0.02) then '共保保额拆分错误'
                                                         else NULL end)                                                     AS `message`,
                                                      (case
                                                         when (
                                                             abs(((`t`.`n_prem` * `t1`.`n_coins_share`) - `t1`.`n_coins_prem`)) >
                                                             0.02) then '共保保费拆分错误'
                                                         else NULL end)                                                     AS `message1`,
                                                      (case
                                                         when (abs(((`t`.`n_notax_prem` * `t1`.`n_coins_share`) -
                                                                    `t1`.`n_coins_notax_prem`)) > 0.02)
                                                           then '共保不含税保费拆分错误'
                                                         else NULL end)                                                     AS `message2`
                                               from (`starr`.`tb_udr_plcy_main` `t`
                                                      join `starr`.`tb_udr_plcy_coins_info` `t1`)
                                               where ((`t`.`c_appl_no` = `t1`.`c_appl_no`) and
                                                      (`t`.`c_coins_type` in ('300063001', '300063003')) and
                                                      (cast(`t`.`d_uptr_time` as date) >=
                                                       cast((now() - interval 1 day) as date)) and
                                                      ((abs(((`t`.`n_amnt` * `t1`.`n_coins_share`) - `t1`.`n_coins_amnt`)) >
                                                        0.02) or
                                                       (abs(((`t`.`n_prem` * `t1`.`n_coins_share`) - `t1`.`n_coins_prem`)) >
                                                        0.02) or (abs(((`t`.`n_notax_prem` * `t1`.`n_coins_share`) -
                                                                       `t1`.`n_coins_notax_prem`)) > 0.02) or (abs(
                                                                                                                   ((`t`.`n_vat_amnt` * `t1`.`n_coins_share`) - `t1`.`n_coins_vat_amnt`)) >
                                                                                                               0.02)))
                                               union
                                               select `t`.`c_appl_no`                                  AS `c_appl_no`,
                                                      `t`.`c_endr_no`                                  AS `c_endr_no`,
                                                      `t`.`n_endr_tms`                                 AS `n_endr_tms`,
                                                      (`t`.`n_amnt` - `t1`.`n_coins_amnt`)             AS `diffamnt`,
                                                      (`t`.`n_prem` - `t1`.`n_coins_prem`)             AS `diffprem`,
                                                      (`t`.`n_notax_prem` - `t1`.`n_coins_notax_prem`) AS `diffnotaxprem`,
                                                      (`t`.`n_vat_amnt` - `t1`.`n_coins_vat_amnt`)     AS `diffvat`,
                                                      `t`.`n_amnt`                                     AS `n_amnt`,
                                                      `t1`.`n_coins_amnt`                              AS `n_coins_amnt`,
                                                      `t`.`n_prem`                                     AS `n_prem`,
                                                      `t1`.`n_coins_prem`                              AS `n_coins_prem`,
                                                      `t`.`n_notax_prem`                               AS `n_notax_prem`,
                                                      `t1`.`n_coins_share`                             AS `n_coins_share`,
                                                      `t1`.`n_coins_notax_prem`                        AS `n_coins_notax_prem`,
                                                      `t`.`n_vat_amnt`                                 AS `n_vat_amnt`,
                                                      `t1`.`n_coins_vat_amnt`                          AS `n_coins_vat_amnt`,
                                                      `t`.`c_biz_type`                                 AS `c_biz_type`,
                                                      `t`.`c_plcy_sts`                                 AS `c_plcy_sts`,
                                                      `t`.`d_crtr_time`                                AS `d_crtr_time`,
                                                      (select `s`.`c_cname`
                                                       from `starr`.`tb_base_comm_code` `s`
                                                       where (`s`.`c_code` = `t`.`c_coins_type`))      AS `Name_exp_20`,
                                                      `t`.`c_renew_mark`                               AS `c_renew_mark`,
                                                      `t`.`d_uptr_time`                                AS `d_uptr_time`,
                                                      (case
                                                         when (abs((`t`.`n_amnt` - `t1`.`n_coins_amnt`)) > 0.02)
                                                           then '从共保我方保额<>整单保险金额'
                                                         else NULL end)                                AS `message`,
                                                      (case
                                                         when (abs((`t`.`n_prem` - `t1`.`n_coins_prem`)) > 0.02)
                                                           then '从共保我方保费<>整单保费'
                                                         else NULL end)                                AS `message1`,
                                                      (case
                                                         when (abs((`t`.`n_notax_prem` - `t1`.`n_coins_notax_prem`)) > 0.02)
                                                           then '从共保我方不含税保费<>整单不含税保费'
                                                         else NULL end)                                AS `message2`
                                               from (`starr`.`tb_udr_plcy_main` `t`
                                                      join `starr`.`tb_udr_plcy_coins_info` `t1`)
                                               where ((`t`.`c_appl_no` = `t1`.`c_appl_no`) and
                                                      (cast(`t`.`d_uptr_time` as date) >=
                                                       cast((now() - interval 1 day) as date)) and
                                                      (`t`.`c_coins_type` = '300063002') and
                                                      (`t1`.`c_joint_guarantee` = '1') and
                                                      (abs(((`t`.`n_amnt` - `t1`.`n_coins_amnt`) > 0.02)) or
                                                       (abs((`t`.`n_prem` - `t1`.`n_coins_prem`)) > 0.02) or
                                                       (abs((`t`.`n_notax_prem` - `t1`.`n_coins_notax_prem`)) > 0.02) or
                                                       (abs((`t`.`n_vat_amnt` - `t1`.`n_coins_vat_amnt`)) > 0.02)));

