create function functionTest(p_con varchar(400)) returns int
BEGIN
return (select count(*) from tb_udr_plcy_main);
end;

