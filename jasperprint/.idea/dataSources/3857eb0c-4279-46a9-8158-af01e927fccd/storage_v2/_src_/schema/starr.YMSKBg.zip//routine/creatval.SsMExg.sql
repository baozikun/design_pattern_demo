create function creatval(seq_name varchar(50)) returns int
BEGIN
DECLARE value INTEGER; 
SET value =1 ;
INSERT INTO ksys_liusdy(xitongbs, farendma, liusbm, liusmc, huancdx, buchang, liuszdz, liuszxz, dangqzh) VALUES ('core', '001', seq_name, seq_name, 100, 1, 99999999, 0, 1); 
RETURN value; 
END;

