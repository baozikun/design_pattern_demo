create procedure gen_policycheck_bycrontab()
begin
	
	
	
	DECLARE v_c_appl_no VARCHAR(50);
	DECLARE v_d_crtr_time VARCHAR(25);
	
	DECLARE v_n_appl_num INTEGER; 
	DECLARE v_n_insrnt_num INTEGER; 
	DECLARE v_same_insrnt_num INTEGER; 
	DECLARE v_nonsame_insrnt_num INTEGER; 
	
	DECLARE v_c_insrnt_flag VARCHAR(50);  
	
	
	DECLARE IS_FOUND INTEGER DEFAULT 1;
		
	
	DECLARE cur1 CURSOR FOR
	 SELECT distinct m.c_appl_no,m.d_crtr_time
	 FROM tb_udr_plcy_main m 
	 where m.d_crtr_time>= DATE_FORMAT(date_sub(DATE_FORMAT(sysdate(),'%Y-%m-%d'),interval 1 day),'%Y-%m-%d %H:%i:%s') 
	 and m.d_crtr_time <= DATE_ADD(DATE_FORMAT(sysdate(),'%Y-%m-%d'),INTERVAL -1 SECOND) 
	 ORDER BY m.d_crtr_time asc;
	  
	 
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET IS_FOUND=0;
	 
	 set v_c_appl_no ='';
	 set v_d_crtr_time='';
	 
  
	OPEN cur1;  
	emp_loop: LOOP
			
			FETCH cur1 INTO v_c_appl_no,v_d_crtr_time; 
			
			set v_n_appl_num = 0;
		  set v_n_insrnt_num = 0;
			set v_same_insrnt_num = 0;
		  set v_nonsame_insrnt_num = 0;
			
			set v_c_insrnt_flag = '01';
				
			IF IS_FOUND=0 THEN 
					LEAVE emp_loop;
			END IF;
			
			
			SELECT count(1) into v_n_appl_num FROM tb_udr_plcy_applnt a where a.c_appl_no = v_c_appl_no and a.c_clnt_type='1' and a.c_certf_type='01';
			SELECT count(1) into v_n_insrnt_num FROM tb_udr_plcy_insrnt r  where r.c_appl_no = v_c_appl_no and r.c_clnt_type='1' and r.c_certf_type='01';
			
			
			IF v_n_appl_num = 0 AND v_n_insrnt_num = 0 THEN
				ITERATE emp_loop;
			END IF;
			
			
			IF v_n_appl_num >0 AND v_n_appl_num >0 THEN
					
					SELECT count(1) into v_same_insrnt_num FROM tb_udr_plcy_insrnt r  where r.c_appl_no = v_c_appl_no and r.c_clnt_type='1' and r.c_certf_type='01' and r.c_ins_insrnt_rel_no = '01';
			
					
					IF v_same_insrnt_num > 0 THEN
							set v_c_insrnt_flag = '03';
					END IF;
							
					
					INSERT INTO tb_integration_policycheck ( c_pk_id, c_insrnt_flag, c_id_type, c_certf_code, c_busi_no, c_bat_no, d_pick_time, c_remark, c_crtr_code, d_crtr_time, c_uptr_code, d_uptr_time ) SELECT
					uuid( ) AS c_pk_id,
					v_c_insrnt_flag AS c_insrnt_flag,
					'0101' AS c_id_type,
					a.c_certf_code AS c_certf_code,
					a.c_appl_no AS c_busi_no,
					'' AS c_bat_no,
					'' AS d_pick_time,
					'' AS c_remark,
					'admin' AS c_crtr_code,
					DATE_FORMAT( SYSDATE(), '%Y-%m-%d %H:%i:%s' ) AS d_crtr_time,
					'admin' AS c_uptr_code,
					DATE_FORMAT( SYSDATE(), '%Y-%m-%d %H:%i:%s' ) AS d_uptr_time 
					FROM
						tb_udr_plcy_applnt a 
					WHERE
						a.c_appl_no = v_c_appl_no 
						AND a.c_clnt_type = '1' 
						AND a.c_certf_type = '01';
							
					
					SELECT count(1) into v_nonsame_insrnt_num FROM tb_udr_plcy_insrnt r  where r.c_appl_no = v_c_appl_no and r.c_clnt_type='1' and r.c_certf_type='01' and r.c_ins_insrnt_rel_no <> '01';
							
					IF v_nonsame_insrnt_num > 0 THEN
							
							INSERT INTO tb_integration_policycheck ( c_pk_id, c_insrnt_flag, c_id_type, c_certf_code, c_busi_no, c_bat_no, d_pick_time, c_remark, c_crtr_code, d_crtr_time, c_uptr_code, d_uptr_time ) SELECT
					uuid( ) AS c_pk_id,
					'02' AS c_insrnt_flag,
					'0101' AS c_id_type,
					a.c_certf_code AS c_certf_code,
					a.c_appl_no AS c_busi_no,
					'' AS c_bat_no,
					'' AS d_pick_time,
					'' AS c_remark,
					'admin' AS c_crtr_code,
					DATE_FORMAT( SYSDATE(), '%Y-%m-%d %H:%i:%s' ) AS d_crtr_time,
					'admin' AS c_uptr_code,
					DATE_FORMAT( SYSDATE(), '%Y-%m-%d %H:%i:%s' ) AS d_uptr_time 
					FROM
						tb_udr_plcy_insrnt a 
					WHERE
						a.c_appl_no = v_c_appl_no 
						AND a.c_clnt_type = '1' 
						AND a.c_certf_type = '01'
						AND a.c_ins_insrnt_rel_no <> '01';
				 END IF;
				
			ELSEIF v_n_appl_num > 0 THEN
					
					INSERT INTO tb_integration_policycheck ( c_pk_id, c_insrnt_flag, c_id_type, c_certf_code, c_busi_no, c_bat_no, d_pick_time, c_remark, c_crtr_code, d_crtr_time, c_uptr_code, d_uptr_time ) SELECT
					uuid( ) AS c_pk_id,
					'01' AS c_insrnt_flag,
					'0101' AS c_id_type,
					a.c_certf_code AS c_certf_code,
					a.c_appl_no AS c_busi_no,
					'' AS c_bat_no,
					'' AS d_pick_time,
					'' AS c_remark,
					'admin' AS c_crtr_code,
					DATE_FORMAT( SYSDATE(), '%Y-%m-%d %H:%i:%s' ) AS d_crtr_time,
					'admin' AS c_uptr_code,
					DATE_FORMAT( SYSDATE(), '%Y-%m-%d %H:%i:%s' ) AS d_uptr_time 
					FROM
						tb_udr_plcy_applnt a 
					WHERE
						a.c_appl_no = v_c_appl_no 
						AND a.c_clnt_type = '1' 
						AND a.c_certf_type = '01';
						
			ELSE   
					
					INSERT INTO tb_integration_policycheck ( c_pk_id, c_insrnt_flag, c_id_type, c_certf_code, c_busi_no, c_bat_no, d_pick_time, c_remark, c_crtr_code, d_crtr_time, c_uptr_code, d_uptr_time ) SELECT
					uuid( ) AS c_pk_id,
					'02' AS c_insrnt_flag,
					'0101' AS c_id_type,
					a.c_certf_code AS c_certf_code,
					a.c_appl_no AS c_busi_no,
					'' AS c_bat_no,
					'' AS d_pick_time,
					'' AS c_remark,
					'admin' AS c_crtr_code,
					DATE_FORMAT( SYSDATE(), '%Y-%m-%d %H:%i:%s' ) AS d_crtr_time,
					'admin' AS c_uptr_code,
					DATE_FORMAT( SYSDATE(), '%Y-%m-%d %H:%i:%s' ) AS d_uptr_time 
					FROM
						tb_udr_plcy_insrnt a 
					WHERE
						a.c_appl_no = v_c_appl_no 
						AND a.c_clnt_type = '1' 
						AND a.c_certf_type = '01';
			END IF;
				 
	END LOOP emp_loop;
	CLOSE cur1; 
end;

