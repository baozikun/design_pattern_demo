create view view_endr_coins_amnt_prem_var_check as
select `t`.`c_appl_no`                                                                  AS `c_appl_no`,
       `t`.`d_crtr_time`                                                                AS `d_crtr_time`,
       `t`.`c_plcy_no`                                                                  AS `c_plcy_no`,
       `t`.`n_endr_tms`                                                                 AS `preEnrtms`,
       `e`.`n_endr_tms`                                                                 AS `nextEnrtms`,
       ((`e`.`n_coins_amnt` - `t`.`n_coins_amnt`) - `e`.`n_amnt_var`)                   AS `amntDiff`,
       ((`e`.`n_coins_prem` - `t`.`n_coins_prem`) - `e`.`n_prem_var`)                   AS `premDiff`,
       ((`e`.`n_coins_notax_prem` - `t`.`n_coins_notax_prem`) - `e`.`n_notax_prem_var`) AS `notaxPremDiff`,
       ((`e`.`n_coins_vat_amnt` - `t`.`n_coins_vat_amnt`) - `e`.`n_vat_amnt_var`)       AS `vatDiff`,
       `t`.`n_coins_amnt`                                                               AS `current_amnt`,
       `e`.`n_coins_amnt`                                                               AS `next_amnt`,
       `e`.`n_amnt_var`                                                                 AS `n_amnt_var`,
       `t`.`n_coins_prem`                                                               AS `current_prem`,
       `e`.`n_coins_prem`                                                               AS `next_prem`,
       `e`.`n_prem_var`                                                                 AS `n_prem_var`,
       `t`.`n_coins_notax_prem`                                                         AS `current_notax_prem`,
       `e`.`n_coins_notax_prem`                                                         AS `next_notax_prem`,
       `e`.`n_notax_prem_var`                                                           AS `N_NOTAX_PREM_VAR`,
       `t`.`n_coins_vat_amnt`                                                           AS `current_vat_amnt`,
       `t`.`n_coins_vat_amnt`                                                           AS `next_vat_amnt`,
       `e`.`n_vat_amnt_var`                                                             AS `n_vat_amnt_var`,
       (case
          when (abs(((`t`.`n_coins_amnt` + `e`.`n_amnt_var`) - `e`.`n_coins_amnt`)) > 0.02)
            then '当前最新保单共保参与方保额<> 上一次有效保单共保方保额+批改共保方保额变化量'
          else '' end)                                                                  AS `message`,
       (case
          when (abs(((`t`.`n_coins_prem` + `e`.`n_prem_var`) - `e`.`n_coins_prem`)) > 0.02)
            then '当前最新保单共保参与方保费<> 上一次有效保单共保方保费+批改共保方保费变化量'
          else '' end)                                                                  AS `message1`,
       (case
          when (abs(((`t`.`n_coins_notax_prem` + `e`.`n_notax_prem_var`) - `e`.`n_coins_notax_prem`)) > 0.02)
            then '当前最新保单共保参与方不含税保费<> 上一次有效保单共保方不含税保费+批改共保方不含税保费变化量'
          else '' end)                                                                  AS `message2`,
       (case
          when (abs(((`t`.`n_coins_vat_amnt` + `e`.`n_vat_amnt_var`) - `e`.`n_coins_vat_amnt`)) > 0.02)
            then '当前最新保单共保参与方税额<> 上一次有效保单共保方税额+批改共保方税额变化量'
          else '' end)                                                                  AS `message3`
from (`starr`.`tb_udr_plcy_coins_info` `t`
       join `starr`.`tb_udr_plcy_coins_info` `e`)
where ((`t`.`c_plcy_no` = `e`.`c_plcy_no`) and
       (cast(`t`.`d_uptr_time` as date) >= cast((now() - interval 1 day) as date)) and
       (`t`.`c_coins_code` = `e`.`c_coins_code`) and ((`t`.`n_endr_tms` + 1) = `e`.`n_endr_tms`) and
       ((abs(((`t`.`n_coins_amnt` + `e`.`n_amnt_var`) - `e`.`n_coins_amnt`)) > 0.02) or
        (abs(((`t`.`n_coins_prem` + `e`.`n_prem_var`) - `e`.`n_coins_prem`)) > 0.02) or
        (abs(((`t`.`n_coins_notax_prem` + `e`.`n_notax_prem_var`) - `e`.`n_coins_notax_prem`)) > 0.02) or
        (abs(((`t`.`n_coins_vat_amnt` + `e`.`n_vat_amnt_var`) - `e`.`n_coins_vat_amnt`)) > 0.02)))
order by `t`.`d_uptr_time` desc;

