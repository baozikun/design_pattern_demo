create procedure update_clmParamCaseAmnt_child(IN in_kind_no varchar(100), IN in_prod_no varchar(100),
                                               IN in_cvrg_no varchar(100), IN in_avg decimal(14, 2))
BEGIN
	DECLARE v_prod_no VARCHAR(100);
	DECLARE v_cvrg_no VARCHAR(100);
	DECLARE v_avg VARCHAR(100);
	
	DECLARE IS_FOUND INTEGER DEFAULT 1;
	DECLARE curCvrgAvgAmntC CURSOR FOR 
		SELECT caseAmnt.c_prod_no,caseAmnt.c_cvrg_no,caseAmnt.n_avg from tb_clm_param_case_amnt caseAmnt;
	
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET IS_FOUND=0;
	
  
	OPEN curCvrgAvgAmntC;  
	cvrgAvgAmntC_loop: LOOP
			
			FETCH curCvrgAvgAmntC INTO v_prod_no,v_cvrg_no,v_avg;
				
			IF IS_FOUND=0 THEN 
					LEAVE cvrgAvgAmntC_loop;
			END IF;
			
			IF v_cvrg_no = in_cvrg_no THEN
					SET v_avg=in_avg;
			ELSEIF v_prod_no = in_prod_no THEN
					SET v_avg=in_avg;
			ELSEIF SUBSTR(v_prod_no,1,2) = in_kind_no THEN
					SET v_avg=in_avg;
			END	IF;
			update tb_clm_param_case_amnt caseAmnt set caseAmnt.n_avg = v_avg WHERE caseAmnt.c_cvrg_no = v_cvrg_no and caseAmnt.c_prod_no = v_prod_no;
			COMMIT;	 
	END LOOP cvrgAvgAmntC_loop;
	CLOSE curCvrgAvgAmntC; 
	
	
	 		

END;

