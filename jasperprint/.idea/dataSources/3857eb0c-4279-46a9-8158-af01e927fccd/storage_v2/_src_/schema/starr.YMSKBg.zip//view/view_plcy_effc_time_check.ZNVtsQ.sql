create view view_plcy_effc_time_check as
select `m`.`c_appl_no`                                                                                            AS `c_appl_no`,
       `t`.`d_crtr_time`                                                                                          AS `d_crtr_time`,
       `t`.`d_ins_effc_from_time`                                                                                 AS `主表保单起保日期`,
       `t`.`d_ins_effc_to_time`                                                                                   AS `主表保单终止日期`,
       `m`.`d_ins_effc_from_time`                                                                                 AS `子表保单起保日期`,
       `m`.`d_ins_effc_to_time`                                                                                   AS `子表保单终保日期`,
       `m`.`c_biz_type`                                                                                           AS `c_biz_type`,
       `m`.`c_plcy_sts`                                                                                           AS `c_plcy_sts`,
       `m`.`c_coins_type`                                                                                         AS `c_coins_type`,
       `m`.`c_renew_mark`                                                                                         AS `c_renew_mark`,
       (case
          when (`m`.`d_ins_effc_from_time` <> `t`.`d_ins_effc_from_time`) then '保单主子表对应起保日期不一致'
          else NULL end)                                                                                          AS `message`,
       (case
          when (`m`.`d_ins_effc_to_time` <> `t`.`d_ins_effc_to_time`) then '保单主子表对应终保日期不一致'
          else NULL end)                                                                                          AS `message1`
from `starr`.`tb_udr_plcy_cvrg` `t`
       join `starr`.`tb_udr_plcy_main` `m`
where ((`m`.`c_appl_no` = `t`.`c_appl_no`) and
       (str_to_date(`t`.`d_crtr_time`, '%Y-%m-%d %H:%i:%s') > str_to_date('2020-05-11', '%Y-%m-%d %H:%i:%s')) and
       ((`m`.`d_ins_effc_from_time` <> `t`.`d_ins_effc_from_time`) or
        (`m`.`d_ins_effc_to_time` <> `t`.`d_ins_effc_to_time`)))
order by `m`.`d_crtr_time` desc;

