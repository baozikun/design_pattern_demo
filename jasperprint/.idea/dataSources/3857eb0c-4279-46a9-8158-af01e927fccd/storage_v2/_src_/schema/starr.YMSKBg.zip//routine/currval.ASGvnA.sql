create function currval(seq_name varchar(50)) returns int
BEGIN
DECLARE value INTEGER; 
SET value = 0; 
SELECT IFNULL(dangqzh,0) INTO value 
FROM ksys_liusdy
WHERE liusbm = seq_name; 
IF value = 0
THEN 
SET value = creatval(seq_name);
END IF;
RETURN value; 
END;

