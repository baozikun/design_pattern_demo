create view view_clmparamcaseamnt as
select `plybase`.`c_kind_no`                                             AS `c_kind_no`,
       `plybase`.`c_prod_no`                                             AS `c_prod_no`,
       `outstdtl`.`c_item`                                               AS `c_item`,
       (sum(`outstdtl`.`n_settl_amnt`) / count(`outstdtl`.`c_notif_no`)) AS `avgSettlAmnt`
from (`starr`.`tb_clm_outst_dtl` `outstdtl`
       join `starr`.`tb_clm_ply_base` `plybase`)
where ((`plybase`.`c_notif_no` = `outstdtl`.`c_notif_no`) and `outstdtl`.`c_prt_id` in (select `outst`.`c_pk_id`
                                                                                        from `starr`.`tb_clm_outst` `outst`
                                                                                        where ((`outst`.`c_new_flag` = '1') and
                                                                                               `outst`.`c_notif_no` in
                                                                                               (select `main`.`c_notif_no`
                                                                                                from `starr`.`tb_clm_main` `main`
                                                                                                where ((`main`.`c_case_status` in ('1', '3')) and
                                                                                                       (`main`.`d_end_time` > (curdate() - interval 3 year)))))))
group by `plybase`.`c_prod_no`,`outstdtl`.`c_item`;

