create procedure gen_integration_templ(OUT msg text)
begin
		
	
	DECLARE v_own_par_code VARCHAR(100);

	DECLARE v_code VARCHAR(100);
	DECLARE v_name VARCHAR(100);
  DECLARE v_par_code VARCHAR(100);
	DECLARE v_type VARCHAR(100);
  DECLARE v_list_code VARCHAR(100);

  
	DECLARE v_path VARCHAR(4000);

	
	DECLARE IS_FOUND INTEGER DEFAULT 1;
	
	
	DECLARE cur1 CURSOR FOR
	 SELECT t.C_CODE,t.C_NAME,t.C_PAR_CODE,t.C_TYPE,COALESCE(t.C_LIST_CODE,'')
		from tb_integration_template t ORDER BY t.N_SEQ*1 asc;
  
	
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET IS_FOUND=0;
		
	SET msg = '';
	SET msg = CONCAT(msg,'<?xml version="1.0" encoding="UTF-8"?>',CHAR(10)) ;
	
	SET v_own_par_code='';

	
	SELECT t.C_CODE,t.C_NAME INTO v_own_par_code,v_name
			FROM tb_integration_template t where t.C_PAR_CODE='00000000' LIMIT 1; 

	set msg = CONCAT(msg,'<root>',CHAR(10)) ;
	set msg = CONCAT(msg,'<policy type="xml" prologue="true" encoding="UTF-8">',CHAR(10)) ;
	set msg = CONCAT(msg,'<struct name="',v_own_par_code,'" desc="',v_name,'" xpath="/',UPPER(v_own_par_code),'">',CHAR(10)) ;  
	
	SET v_code='';
	SET v_name='';
	SET v_par_code ='';
	SET v_type='';
	SET v_list_code='';
	SET v_path = '';
	
  
	OPEN cur1;  
	emp_loop: LOOP
			
			FETCH cur1 INTO v_code,v_name,v_par_code,v_type,v_list_code; 
				
			IF IS_FOUND=0 THEN 
					LEAVE emp_loop;
			END IF;
			
      
			IF v_type='0' AND  v_par_code = v_own_par_code THEN
				 	SET msg = CONCAT(msg,'<field name="',v_code,'" desc="',v_name,'" xpath="',UPPER(v_code),'"/>',CHAR(10));	
			END IF;
			
			
			IF v_type='1' AND  v_par_code = v_own_par_code THEN
					SET v_path = CONCAT(UPPER(v_own_par_code),'/',UPPER(v_code));
				 	SET msg = CONCAT(msg,'<struct name="',v_code,'" desc="',v_name,'" xpath="/',v_path,'">',CHAR(10));
					
					CALL gen_integration_templ_child(msg,v_type,v_code,v_path,@out_msg);
					SELECT @out_msg INTO msg;
					SET msg = CONCAT(msg,'</struct>',CHAR(10));
			END IF;
			
			
			IF v_type='2' AND  v_par_code = v_own_par_code THEN
					SET msg = CONCAT(msg,'<struct desc="',v_name,'" xpath="/',UPPER(v_own_par_code),'/',UPPER(v_list_code),'">',CHAR(10));
					SET v_path = CONCAT(UPPER(v_own_par_code),'/',UPPER(v_list_code),'/',UPPER(v_code));
					SET msg = CONCAT(msg,'<loop name="',v_code,'" desc="',v_name,'" xpath="/',v_path,'">',CHAR(10));	
					
					CALL gen_integration_templ_child(msg,v_type,v_code,v_path,@out_msg);
					SELECT @out_msg INTO msg;
					SET msg = CONCAT(msg,'</loop>',CHAR(10));
					SET msg = CONCAT(msg,'</struct>',CHAR(10));
			END IF;
				 
	END LOOP emp_loop;
	CLOSE cur1; 
	 		
	SET msg = CONCAT(msg,'</struct>',CHAR(10));	
	SET msg = CONCAT(msg,'</policy>',CHAR(10));	
	SET msg = CONCAT(msg,'</root>',CHAR(10));	

end;

