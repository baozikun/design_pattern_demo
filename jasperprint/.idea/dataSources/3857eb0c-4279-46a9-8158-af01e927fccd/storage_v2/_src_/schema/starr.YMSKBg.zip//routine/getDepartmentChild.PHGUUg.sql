create function getDepartmentChild(rootId longtext) returns longtext
BEGIN
        DECLARE ptemp longtext;
        DECLARE ctemp longtext;
               SET ptemp = '#';
               SET ctemp =rootId;
               WHILE ctemp IS NOT NULL DO
                 SET ptemp = CONCAT(ptemp,',',ctemp);
                SELECT GROUP_CONCAT(c_dept_code) INTO ctemp FROM TB_PARTY_DEPARTMENT   
                WHERE FIND_IN_SET(c_par_dept_code,ctemp)>0 ; 
               END WHILE;  
               RETURN ptemp;  
    END;

