create view view_cvrg_n_notax_prem_check as
select `t`.`c_appl_no`                                                    AS `c_appl_no`,
       `t`.`c_cvrg_no`                                                    AS `c_cvrg_no`,
       `t`.`n_amnt`                                                       AS `保额`,
       cast(`t`.`n_pay_prem` as decimal(20, 2))                           AS `应缴保费`,
       `t`.`c_vat_flag`                                                   AS `应税标志`,
       `t`.`n_vat_rate`                                                   AS `税率`,
       cast(`t`.`n_notax_prem` as decimal(20, 2))                         AS `不含税保费`,
       cast(`t`.`n_vat_amnt` as decimal(20, 2))                           AS `税额`,
       `t`.`d_ins_effc_from_time`                                         AS `d_ins_effc_from_time`,
       `t`.`d_ins_effc_to_time`                                           AS `d_ins_effc_to_time`,
       (case when (`t`.`n_notax_prem` < 0) then '险别不含税保费小于0' else '' end) AS `message`,
       (case
          when ((`t`.`n_notax_prem` + `t`.`n_vat_amnt`) <> cast(`t`.`n_pay_prem` as decimal(20, 2)))
            then '险别级不含税+税额<>应缴含税金额'
          else NULL end)                                                  AS `message1`
from `starr`.`tb_udr_plcy_cvrg` `t`
where ((`t`.`n_notax_prem` < 0) or
       ((`t`.`n_notax_prem` + `t`.`n_vat_amnt`) <> cast(`t`.`n_pay_prem` as decimal(20, 2))))
limit 1,100;

