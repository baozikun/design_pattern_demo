create view view_plcy_laster_plcy_flag_check as select `s`.`c_plcy_no`                                                          AS `c_plcy_no`,
                                                       `s`.`c_appl_no`                                                          AS `c_appl_no`,
                                                       `s`.`c_endr_no`                                                          AS `c_endr_no`,
                                                       `s`.`n_endr_tms`                                                         AS `n_endr_tms`,
                                                       `s`.`c_latest_plcy_flag`                                                 AS `c_latest_plcy_flag`,
                                                       `s`.`d_uptr_time`                                                        AS `d_uptr_time`,
                                                       (case when (`s`.`c_latest_plcy_flag` = '0') then '最新保单标志为0' else '' end) AS `message`
                                                from (`starr`.`tb_udr_plcy_main` `s`
                                                       join (select `p`.`c_plcy_no` AS `c_plcy_no`,max(`p`.`n_endr_tms`) AS `maxtms`
                                                             from `starr`.`tb_udr_plcy_main` `p`
                                                             where (`p`.`n_endr_tms` > 0)
                                                             group by `p`.`c_plcy_no`) `t`)
                                                where ((`s`.`c_plcy_no` = `t`.`c_plcy_no`) and
                                                       (`s`.`n_endr_tms` = `t`.`maxtms`) and
                                                       (`s`.`c_latest_plcy_flag` = '0'))
                                                union all
                                                select `s`.`c_plcy_no`                                                          AS `c_plcy_no`,
                                                       `s`.`c_appl_no`                                                          AS `c_appl_no`,
                                                       `s`.`c_endr_no`                                                          AS `c_endr_no`,
                                                       `s`.`n_endr_tms`                                                         AS `n_endr_tms`,
                                                       `s`.`c_latest_plcy_flag`                                                 AS `c_latest_plcy_flag`,
                                                       `s`.`d_uptr_time`                                                        AS `d_uptr_time`,
                                                       (case when (`s`.`c_latest_plcy_flag` = '0') then '最新保单标志为0' else '' end) AS `case when s.c_latest_plcy_flag = '0' then '最新保单标志为0' else '' end`
                                                from (select `t`.`c_plcy_no`          AS `c_plcy_no`,
                                                             `t`.`c_appl_no`          AS `c_appl_no`,
                                                             `t`.`c_endr_no`          AS `c_endr_no`,
                                                             `t`.`n_endr_tms`         AS `n_endr_tms`,
                                                             `t`.`c_latest_plcy_flag` AS `c_latest_plcy_flag`,
                                                             `t`.`d_uptr_time`        AS `d_uptr_time`
                                                      from `starr`.`tb_udr_plcy_main` `t`
                                                      where (`t`.`C_DATA_SRC` <> 'E-CARGO')
                                                      group by `t`.`c_plcy_no`
                                                      having (count(1) = 1)) `s`
                                                where (`s`.`c_latest_plcy_flag` = 0);

