create procedure update_clmParamCaseAmnt()
begin
		
	
	DECLARE v_kind_no VARCHAR(100);
	DECLARE v_prod_no VARCHAR(100);
	DECLARE v_cvrg_no VARCHAR(100);
	DECLARE v_avg DECIMAL(14,2);
	
	DECLARE IS_FOUND INTEGER DEFAULT 1;
	
	DECLARE curCvrgAvgAmnt CURSOR FOR 
	SELECT plyBase.c_kind_no,plyBase.c_prod_no,outstDtl.c_item,sum(outstDtl.n_settl_amnt) / count(outstDtl.c_notif_no) AS avgSettlAmnt
	FROM tb_clm_outst_dtl outstDtl,tb_clm_ply_base plyBase
	WHERE
		plyBase.c_notif_no = outstDtl.c_notif_no
	AND outstDtl.c_prt_id IN (
		SELECT
			outst.c_pk_id
		FROM
			tb_clm_outst outst
		WHERE
			outst.c_new_flag = '1'
		AND outst.c_notif_no IN (
			SELECT
				main.c_notif_no
			FROM
				tb_clm_main main
			WHERE
				main.c_case_status IN ('1', '3')
			AND main.d_end_time > DATE_SUB(CURDATE(), INTERVAL 3 YEAR)
		)
	)
	GROUP BY
		plyBase.c_prod_no,
		outstDtl.c_item;
  
	
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET IS_FOUND=0;

	
	delete from tb_clm_param_case_amnt  where c_year <> YEAR(CURDATE());
	COMMIT;
	
	
	INSERT INTO TB_CLM_PARAM_CASE_AMNT (
	c_pk_id,
	c_dept_code,
	c_prod_no,
	c_cvrg_no,
	c_loss_type_code,
	c_year,
	n_avg,
	c_flag,
	c_crtr_code,
	d_crtr_time,
	c_uptr_code,
	d_uptr_time
	) SELECT
		UUID() AS c_pk_id,
		'00000000' AS c_dept_code,
		cvrgRel.c_prod_no AS c_prod_no,

	IF (
		(cvrgRel.c_addi_cvrg_no = '' or cvrgRel.c_addi_cvrg_no IS NULL ),
		cvrgRel.c_main_cvrg_no,
		cvrgRel.c_addi_cvrg_no
	) AS c_cvrg_no,
	 '' AS c_loss_type_code,
	 YEAR(CURDATE()) AS c_year,
	 '0.00' AS n_avg,
	 '1' AS c_flag,
	 'system' AS c_crtr_code,
	 SYSDATE() AS d_crtr_time,
	 'system' AS c_uptr_code,
	 SYSDATE() AS d_uptr_time
	FROM
		tb_prod_dfn_cvrg_rel cvrgRel,
		tb_prod_dfn_product product
	WHERE
		product.c_del_flag = '0'
	AND product.c_status = '1'
	AND cvrgRel.c_prod_no = product.c_prod_no
	AND (
		cvrgRel.c_prod_no,

	IF (
		(cvrgRel.c_addi_cvrg_no = '' or cvrgRel.c_addi_cvrg_no IS NULL ),
		cvrgRel.c_main_cvrg_no,
		cvrgRel.c_addi_cvrg_no
	),
	 YEAR (CURDATE())
	) NOT IN (
		SELECT
			caseAmnt.c_prod_no,
			caseAmnt.c_cvrg_no,
			caseAmnt.c_year
		FROM
			tb_clm_param_case_amnt caseAmnt
	);
	COMMIT;
	 

	
  
	OPEN curCvrgAvgAmnt;  
	cvrgAvgAmnt_loop: LOOP
			
			FETCH curCvrgAvgAmnt INTO v_kind_no,v_prod_no,v_cvrg_no,v_avg;
				
			IF IS_FOUND=0 THEN 
					LEAVE cvrgAvgAmnt_loop;
			END IF;
			
			IF v_avg = 0 or v_avg is null THEN
					SET v_avg = (SELECT sum(avgSettlAmnt)/count(c_item) from view_clmparamcaseamnt where c_prod_no=v_prod_no and avgSettlAmnt <> 0 );
			END IF;
			
			IF v_avg = 0 or v_avg is null THEN
					SET  v_avg = (SELECT sum(avgSettlAmnt)/count(c_prod_no) from view_clmparamcaseamnt where c_kind_no=v_kind_no and avgSettlAmnt <> 0 );
			END IF;
			
			CALL update_clmParamCaseAmnt_child(v_kind_no,v_prod_no,v_cvrg_no,v_avg);
				 
	END LOOP cvrgAvgAmnt_loop;
	CLOSE curCvrgAvgAmnt; 
	
	
	 		


end;

