create view view_endr_fee_check as
select `t`.`c_appl_no`                                                               AS `c_appl_no`,
       `t`.`d_crtr_time`                                                             AS `d_crtr_time`,
       `t`.`c_plcy_no`                                                               AS `c_plcy_no`,
       `t`.`n_endr_tms`                                                              AS `n_endr_tms`,
       `e`.`n_endr_tms`                                                              AS `e_endr_tms`,
       `t`.`n_dis_rate`                                                              AS `n_dis_rate`,
       `e`.`n_dis_rate`                                                              AS `e_dis_Rate`,
       `t`.`n_fee`                                                                   AS `n_n_fee`,
       `e`.`n_fee`                                                                   AS `e_n_fee`,
       `e`.`n_fee_var`                                                               AS `n_fee_var`,
       ((`e`.`n_fee` - `t`.`n_fee`) - `e`.`n_fee_var`)                               AS `feeDiff`,
       `t`.`n_perf_one_amnt`                                                         AS `n_n_perf_one_amnt`,
       `e`.`n_perf_one_amnt`                                                         AS `e_n_perf_one_amnt`,
       `e`.`n_perf_one_amnt_var`                                                     AS `n_perf_one_amnt_var`,
       ((`e`.`n_perf_one_amnt` - `t`.`n_perf_one_amnt`) - `e`.`n_perf_one_amnt_var`) AS `jixiaoDiff`,
       `t`.`n_skill_fee`                                                             AS `n_n_skill_fee`,
       `e`.`n_skill_fee`                                                             AS `e_n_skill_fee`,
       `e`.`n_skill_fee_var`                                                         AS `n_skill_fee_var`,
       ((`e`.`n_skill_fee` - `t`.`n_skill_fee`) - `e`.`n_skill_fee_var`)             AS `skillDiff`,
       `t`.`n_dis_amnt`                                                              AS `n_n_dis_amnt`,
       `e`.`n_dis_amnt`                                                              AS `e_n_dis_amnt`,
       `e`.`n_dis_amnt_var`                                                          AS `n_dis_amnt_var`,
       ((`e`.`n_dis_amnt` - `t`.`n_dis_amnt`) - `e`.`n_dis_amnt_var`)                AS `disDiff`,
       (case
          when (abs(((`t`.`n_fee` + `e`.`n_fee_var`) - `e`.`n_fee`)) > 0.02) then '批改后最新保单费用金额<>上一张最新有效保单费用金额+本次批改费用变化量'
          else NULL end)                                                             AS `message`,
       (case
          when (abs(((`t`.`n_dis_amnt` + `e`.`n_dis_amnt_var`) <> `e`.`n_dis_amnt`)) > 0.02)
            then '批改后最新保单手续费税额<>上一张最新有效保单手续费税额+本次批改手续费税额变化量'
          else NULL end)                                                             AS `message2`
from (`starr`.`tb_udr_plcy_fee` `t`
       join `starr`.`tb_udr_plcy_fee` `e`)
where ((`t`.`c_plcy_no` = `e`.`c_plcy_no`) and
       (cast(`t`.`d_uptr_time` as date) = cast((now() - interval 1 day) as date)) and
       ((`t`.`n_endr_tms` + 1) = `e`.`n_endr_tms`) and ((abs(((`t`.`n_fee` + `e`.`n_fee_var`) - `e`.`n_fee`)) > 0.02) or
                                                        (abs(((`t`.`n_perf_one_amnt` + `e`.`n_perf_one_amnt_var`) <>
                                                              `e`.`n_perf_one_amnt`)) > 0.02) or (abs(
                                                                                                      ((`t`.`n_skill_fee` + `e`.`n_skill_fee_var`) - `e`.`n_skill_fee`)) >
                                                                                                  0.02) or (abs(
                                                                                                                ((`t`.`n_dis_amnt` + `e`.`n_dis_amnt_var`) <> `e`.`n_dis_amnt`)) >
                                                                                                            0.02)))
order by `t`.`d_crtr_time` desc;

