create view view_plcy_insurant_clntno_check as
select `s`.`c_appl_no`                                                                                       AS `c_appl_no`,
       `s`.`c_clnt_no`                                                                                       AS `c_clnt_no`,
       (case
          when ((length(`s`.`c_clnt_no`) = 0) or isnull(`s`.`c_clnt_no`)) then '被保人客户代码为空'
          else NULL end)                                                                                     AS `message`,
       '同一投保单下被保人客户代码重复'                                                                                     AS `message1`
from (select `t`.`c_appl_no` AS `c_appl_no`,`t`.`c_clnt_no` AS `c_clnt_no`
      from `starr`.`tb_udr_plcy_insrnt` `t`
             join `starr`.`tb_udr_plcy_main` `m`
      where ((`t`.`c_appl_no` = `m`.`c_appl_no`) and
             (cast(`m`.`d_uptr_time` as date) >= cast((now() - interval 2 day) as date)))) `s`
group by `s`.`c_appl_no`,`s`.`c_clnt_no`
having (count(1) > 1);

