create procedure gen_integration_templ_child(IN in_msg text, IN in_type varchar(100), IN in_par_code varchar(100),
                                             IN in_path varchar(4000), OUT out_msg text)
begin

		DECLARE v_code VARCHAR(100);
		DECLARE v_name VARCHAR(100);
		DECLARE v_par_code VARCHAR(100);
		DECLARE v_type VARCHAR(100);
		DECLARE v_list_code VARCHAR(100);
		
		
		DECLARE v_path VARCHAR(4000);

		
		DECLARE IS_FOUND INTEGER DEFAULT 1;
		
		
		DECLARE cur1 CURSOR FOR
		 SELECT t.C_CODE,t.C_NAME,t.C_PAR_CODE,t.C_TYPE,COALESCE(t.C_LIST_CODE,'')
			from tb_integration_template t where t.c_par_code= in_par_code ORDER BY t.N_SEQ*1 asc;
		
		
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET IS_FOUND=0;
		
		
		SET @@max_sp_recursion_depth = 100;

		SET v_code='';
		SET v_name='';
		SET v_par_code ='';
		SET v_type='';
		SET v_list_code='';

		SET v_path ='';

		SET out_msg = in_msg;

		
		open cur1;
			child_loop : LOOP
					FETCH cur1 INTO v_code,v_name,v_par_code,v_type,v_list_code; 

					IF IS_FOUND=0 THEN 
							LEAVE child_loop;
					END IF;
					
					
					IF v_type='0' AND  v_par_code = in_par_code THEN
							SET out_msg = CONCAT(out_msg,'<field name="',v_code,'" desc="',v_name,'" xpath="',UPPER(v_code),'"/>',CHAR(10));	
					END IF;

					
					IF v_type='1' AND  v_par_code = in_par_code THEN
							SET v_path = CONCAT(UPPER(in_path),'/',UPPER(v_code));
							SET out_msg = CONCAT(out_msg,'<struct name="',v_code,'" desc="',v_name,'" xpath="/',v_path,'">',CHAR(10));
							
							CALL gen_integration_templ_child(out_msg,v_type,v_code,v_path,@out_msg2);
							SELECT @out_msg2 INTO out_msg;
							SET out_msg = CONCAT(out_msg,'</struct>',CHAR(10));
					END IF;
					
					
					IF v_type='2' AND  v_par_code = in_par_code THEN
							SET out_msg = CONCAT(out_msg,'<struct desc="',v_name,'" xpath="/',UPPER(in_path),'/',UPPER(v_list_code),'">',CHAR(10));
							SET v_path = CONCAT(UPPER(in_path),'/',UPPER(v_list_code),'/',UPPER(v_code));
							SET out_msg = CONCAT(out_msg,'<loop name="',v_code,'" desc="',v_name,'" xpath="/',v_path,'">',CHAR(10));	
							
							CALL gen_integration_templ_child(out_msg,v_type,v_code,v_path,@out_msg2);
							SELECT @out_msg2 INTO out_msg;
							SET out_msg = CONCAT(out_msg,'</loop>',CHAR(10));
							SET out_msg = CONCAT(out_msg,'</struct>',CHAR(10));
					END IF;
					
			END LOOP child_loop;						
		CLOSE cur1;

END;

