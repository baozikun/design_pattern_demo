create procedure fnStripTags()
BEGIN
  declare iStart, iEnd, iLength int;
  declare context longtext;
  declare done int DEFAULT 0; 
 declare businessid varchar(200);
  declare  replaceText cursor  for (select t.ibusinessiD ,t.ClauseContent from starr.test t); 
  declare continue handler for not found set done  =1;
 	open replaceText;
 
  	
   while done <> 1 do 
		fetch next from replaceText into businessid,context;
		if done <> 1 then 
			WHILE Locate( '<', context ) > 0 And Locate( '>', context, Locate( '<', context )) > 0 DO
		      BEGIN
		        SET iStart = Locate( '<', context ), iEnd = Locate( '>', context, Locate('<', context ));
		        SET iLength = ( iEnd - iStart) + 1;
		        IF iLength > 0 THEN
		            SET context = Insert( context, iStart, iLength, '');
		           update starr.test t set t.ClauseContent = Insert( context, iStart, iLength, '') where t.ibusinessiD  = businessid;
		          commit;
		        END IF;
		      END;
		    END WHILE;
		end if;

  end while;
  close replaceText;
END;

