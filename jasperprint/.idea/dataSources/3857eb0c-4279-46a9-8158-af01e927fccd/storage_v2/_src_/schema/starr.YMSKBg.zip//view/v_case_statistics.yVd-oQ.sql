create view v_case_statistics as
select `b`.`c_opoly_agrmnt_no` AS `opolyAgrmntNo`,count(1) AS `ClaimsNum`,sum(`o`.`n_settl_amnt`) AS `ClaimsAmount`
from ((`starr`.`tb_clm_ply_base` `b` join `starr`.`tb_clm_main` `m`)
       join `starr`.`tb_clm_outst` `o`)
where ((`b`.`c_opoly_agrmnt_no` <> '') and (`m`.`c_notif_no` = `b`.`c_notif_no`) and
       (`m`.`c_case_status` in ('1', '3')) and (`o`.`c_notif_no` = `b`.`c_notif_no`) and
       (`o`.`c_notif_no` = `m`.`c_notif_no`) and (`o`.`c_new_flag` = '1'))
group by `b`.`c_opoly_agrmnt_no`;

