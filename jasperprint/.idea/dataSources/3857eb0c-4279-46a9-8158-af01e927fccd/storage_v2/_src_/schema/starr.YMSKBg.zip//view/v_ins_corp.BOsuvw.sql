create view v_ins_corp as
select `c`.`c_insco_code`  AS `c_insco_code`,
       `c`.`c_insco_cname` AS `c_insco_cname`,
       `c`.`c_insco_ename` AS `c_insco_ename`,
       `c`.`c_ri_mark`     AS `c_ri_mark`,
       `c`.`c_co_mark`     AS `c_co_mark`,
       `c`.`c_status`      AS `c_status`,
       `c`.`c_ins_del`     AS `c_ins_del`
from `starr`.`tb_party_ins_corp` `c`
order by `c`.`c_insco_code`;

