create function getDeptRelCode(deptCode longtext) returns longtext
BEGIN
	
  DECLARE relDeptCode longtext;
  DECLARE paramDeptCode longtext;
  SET paramDeptCode=deptCode;
	select concat(c_dept_rel_code,'%') into relDeptCode from tb_party_department where c_dept_code=paramDeptCode;

	RETURN relDeptCode;
END;

