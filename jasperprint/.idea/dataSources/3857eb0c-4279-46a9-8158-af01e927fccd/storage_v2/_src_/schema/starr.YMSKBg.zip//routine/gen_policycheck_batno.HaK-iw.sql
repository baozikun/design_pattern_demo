create procedure gen_policycheck_batno()
begin
	
	DECLARE v_c_certf_code VARCHAR(50);
	
	DECLARE v_history_num INTEGER; 
		
	
	DECLARE IS_FOUND INTEGER DEFAULT 1;
		
	
	
	
	DECLARE cur1 CURSOR FOR
	SELECT p.c_certf_code FROM tb_integration_policycheck p where DATE_FORMAT(p.d_crtr_time,'%Y-%m-%d') = DATE_FORMAT(sysdate(),'%Y-%m-%d') GROUP BY p.c_certf_code;
	  
	 
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET IS_FOUND=0;
	 
	set v_c_certf_code ='';
	 
  
	OPEN cur1;  
	emp_loop: LOOP
			
			set v_history_num = 0;
			
			FETCH cur1 INTO v_c_certf_code; 
				
			IF IS_FOUND=0 THEN 
					LEAVE emp_loop;
			END IF;
			
			
			SELECT count(1) into v_history_num from tb_integration_policycheck p  where DATE_FORMAT(p.d_crtr_time,'%Y-%m-%d') = DATE_FORMAT(date_sub(SYSDATE(),interval 1 day),'%Y-%m-%d') and p.c_certf_code = v_c_certf_code;

			
			IF v_history_num >0 THEN
					ITERATE emp_loop;
			END IF;
			
			
			update tb_integration_policycheck p 
			set p.c_bat_no = uuid() 
			where DATE_FORMAT(p.d_crtr_time,'%Y-%m-%d') = DATE_FORMAT(sysdate(),'%Y-%m-%d') and p.c_certf_code = v_c_certf_code;

				 
	END LOOP emp_loop;
	CLOSE cur1; 
end;

