create view view_endr_amount_prem_check as
select `t`.`c_appl_no`                                                               AS `c_appl_no`,
       `t`.`d_crtr_time`                                                             AS `d_crtr_time`,
       `e`.`c_endr_type`                                                             AS `c_endr_type`,
       `e`.`n_endr_tms`                                                              AS `n_endr_tms`,
       ((`e`.`n_aft_endr_amnt` - `t`.`n_amnt`) - `e`.`n_amnt_var`)                   AS `amntDiff`,
       ((`e`.`n_aft_endr_prem` - `t`.`n_prem`) - `e`.`n_prem_var`)                   AS `premDiff`,
       ((`e`.`n_aft_endr_notax_prem` - `t`.`n_notax_prem`) - `e`.`N_NOTAX_PREM_VAR`) AS `notaxPremDiff`,
       `t`.`n_amnt`                                                                  AS `m_n_amnt`,
       `e`.`n_aft_endr_amnt`                                                         AS `e_n_amnt`,
       `e`.`n_amnt_var`                                                              AS `n_amnt_var`,
       `t`.`n_prem`                                                                  AS `m_n_prem`,
       `e`.`n_aft_endr_prem`                                                         AS `e_n_prem`,
       `e`.`n_prem_var`                                                              AS `n_prem_var`,
       `t`.`n_notax_prem`                                                            AS `m_n_notax_prem`,
       `e`.`n_aft_endr_notax_prem`                                                   AS `e_n_notax_prem`,
       `e`.`N_NOTAX_PREM_VAR`                                                        AS `n_notax_prem_var`,
       `t`.`n_vat_amnt`                                                              AS `m_n_vat_amnt`,
       `e`.`N_TAX_PREM_VAR`                                                          AS `n_tax_prem_var`,
       `t`.`c_biz_type`                                                              AS `c_biz_type`,
       `t`.`c_plcy_sts`                                                              AS `c_plcy_sts`,
       `t`.`c_coins_type`                                                            AS `c_coins_type`,
       `t`.`c_renew_mark`                                                            AS `c_renew_mark`,
       (case
          when (abs(((`t`.`n_amnt` + `e`.`n_amnt_var`) - `e`.`n_aft_endr_amnt`)) > 0.02)
            then '批改后保额不等于上次(上一次有效保单)最新+本次批改保额变化量 <> 本次最新保单保额'
          else NULL end)                                                             AS `message`,
       (case
          when (abs(((`t`.`n_prem` + `e`.`n_prem_var`) - `e`.`n_aft_endr_prem`)) > 0.02)
            then '批改后含税保费不等于上次(上一次有效保单)最新+本次批改保费变化量 <> 本次最新保单保费'
          else NULL end)                                                             AS `message1`,
       (case
          when (abs(((`t`.`n_notax_prem` + `e`.`N_NOTAX_PREM_VAR`) - `e`.`n_aft_endr_notax_prem`)) > 0.02)
            then '批改后净保费不等于上次(上一次有效保单)最新+本次批改净变化量 <> 本次最新保单不含税保费'
          else NULL end)                                                             AS `message2`
from (`starr`.`tb_udr_plcy_main` `t`
       join `starr`.`tb_udr_plcy_endr` `e`)
where ((`t`.`c_plcy_no` = `e`.`c_plcy_no`) and
       (str_to_date(`t`.`d_crtr_time`, '%Y-%m-%d %H:%i:%s') > str_to_date('2020-05-11', '%Y-%m-%d %H:%i:%s')) and
       ((`t`.`n_endr_tms` + 1) = `e`.`n_endr_tms`) and
       ((abs(((`t`.`n_amnt` + `e`.`n_amnt_var`) - `e`.`n_aft_endr_amnt`)) > 0.02) or
        (abs(((`t`.`n_prem` + `e`.`n_prem_var`) - `e`.`n_aft_endr_prem`)) > 0.02) or
        (abs(((`t`.`n_notax_prem` + `e`.`N_NOTAX_PREM_VAR`) - `e`.`n_aft_endr_notax_prem`)) > 0.02)))
order by `t`.`d_uptr_time` desc;

