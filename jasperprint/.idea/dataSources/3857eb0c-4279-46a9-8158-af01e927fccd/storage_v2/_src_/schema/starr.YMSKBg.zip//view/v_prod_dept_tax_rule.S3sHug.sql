create view v_prod_dept_tax_rule as
select distinct `c`.`C_OLD_CODE`     AS `c_prod_no`,
                `p`.`c_prod_name`    AS `c_prod_name`,
                `t`.`c_dept_code`    AS `c_dept_code`,
                `t`.`c_taxflag`      AS `c_taxflag`,
                `t`.`n_vat_rate`     AS `n_vat_rate`,
                `p`.`d_invalid_time` AS `d_invalid_time`,
                `p`.`d_crtr_time`    AS `d_crtr_time`,
                `p`.`d_uptr_time`    AS `d_uptr_time`
from ((`starr`.`tb_prod_dfn_product` `p` join `starr`.`tb_prod_cvrg_rel_tax` `t`)
       join `starr`.`tb_trans_code` `c`)
where ((`p`.`c_prod_no` = `t`.`c_prod_no`) and (`p`.`c_chnl_code` = 'CA01') and (`c`.`C_NEW_CODE` = `t`.`c_prod_no`) and
       (`c`.`C_NEW_CODE` = `p`.`c_prod_no`) and (`c`.`C_OLD_TYPE` = 'TRPROD'))
order by `p`.`d_uptr_time` desc,`p`.`c_prod_no`,`t`.`c_dept_code`;

