create view view_plcy_coinsrate_check as
select `t`.`c_appl_no`                                                             AS `c_appl_no`,
       sum(`t`.`n_coins_share`)                                                    AS `sumcoinsrate`,
       `t`.`d_uptr_time`                                                           AS `d_uptr_time`,
       (case when (sum(`t`.`n_coins_share`) <> 1) then '共保比例之和不等于1' else NULL end) AS `message`
from `starr`.`tb_udr_plcy_coins_info` `t`
where (cast(`t`.`d_uptr_time` as date) >= cast((now() - interval 1 day) as date))
group by `t`.`c_appl_no`
having (sum(`t`.`n_coins_share`) <> 1);

