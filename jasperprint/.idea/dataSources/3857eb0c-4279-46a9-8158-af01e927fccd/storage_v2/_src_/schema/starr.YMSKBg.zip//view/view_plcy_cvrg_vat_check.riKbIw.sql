create view view_plcy_cvrg_vat_check as
select `m`.`c_appl_no`                                                        AS `c_appl_no`,
       `m`.`c_cvrg_no`                                                        AS `险别代码`,
       `m`.`n_pay_prem`                                                       AS `应缴保费`,
       `m`.`c_vat_flag`                                                       AS `险别应免税标志`,
       `m`.`n_vat_rate`                                                       AS `税率`,
       `m`.`n_notax_prem`                                                     AS `不含税保费`,
       `m`.`n_vat_amnt`                                                       AS `税额`,
       `m`.`d_ins_effc_from_time`                                             AS `保险起期`,
       `m`.`d_ins_effc_to_time`                                               AS `保险止期`,
       cast(((`m`.`n_pay_prem` * `m`.`n_vat_rate`) / 1.06) as decimal(20, 2)) AS `校对税额`,
       (`m`.`n_notax_prem` + `m`.`n_vat_amnt`)                                AS `校对含税保费`,
       (case
          when (`m`.`n_vat_amnt` <> cast(((`m`.`n_pay_prem` * `m`.`n_vat_rate`) / 1.06) as decimal(20, 2)))
            then '险别级应缴含税金额<> 不含税+税额'
          else '' end)                                                        AS `message`,
       (case
          when ((`m`.`n_notax_prem` + `m`.`n_vat_amnt`) <> `m`.`n_pay_prem`) then '险别级应缴含税保费<> 不含税保费+税额'
          else '' end)                                                        AS `message2`
from `starr`.`tb_udr_plcy_cvrg` `m`
where ((cast(`m`.`d_uptr_time` as date) >= cast((now() - interval 1 day) as date)) and
       ((`m`.`n_vat_amnt` <> cast(((`m`.`n_pay_prem` * `m`.`n_vat_rate`) / 1.06) as decimal(20, 2))) or
        ((`m`.`n_notax_prem` + `m`.`n_vat_amnt`) <> `m`.`n_pay_prem`)));

