create procedure test(IN prodCode varchar(30), IN compCode varchar(30), IN fieldName varchar(50))
BEGIN
	DECLARE done INT DEFAULT 0;
	declare elem_count int default 0;
	DECLARE prod_screen_no VARCHAR(30);
	DECLARE prod_no VARCHAR(30);
	DECLARE prod_id VARCHAR(50);
	DECLARE prod_version VARCHAR(10);
	DECLARE cur_screenno CURSOR FOR 
	SELECT DISTINCT t.c_screen_no, k.c_prod_no,k.c_pk_id,k.c_version FROM tb_prod_screen_rel_elem t LEFT JOIN tb_prod_dfn_product k ON t.c_prod_no = k.c_prod_no
WHERE t.c_comp_code = compCode and t.c_prod_no = '0100';
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
      

    OPEN cur_screenno;
    read_loop: LOOP
    FETCH cur_screenno INTO prod_screen_no,prod_no,prod_id,prod_version;
	IF done =1 THEN
		LEAVE read_loop;
	END IF;
	
	select count(*) into elem_count from tb_prod_screen_rel_elem where c_prod_no = prod_no and c_prod_id = prod_id 
	and c_version = prod_version and c_screen_no = prod_screen_no and c_rel_field_name = fieldName;
	if elem_count > 0 then
		leave read_loop;
	end if;
	
        INSERT INTO tb_prod_screen_rel_elem
            (c_pk_id,
             c_screen_no,
             c_elem_no,
             c_contrl_type,
             c_check_type,
             c_must_intput_flag,
             c_read_only_flag,
             c_view_show_flag,
             c_dflt_value,
             c_min_value,
             c_max_value,
             c_precision,
             d_crtr_time,
             d_uptr_time,
             c_crtr_code,
             c_uptr_code,
             c_comp_code,
             c_code_list_name,
             n_string_length,
             c_clk_event_func,
             n_elem_show_seq,
             c_elem_cname,
             c_elem_ename,
             c_rel_field_name,
             c_rel_table_name,
             c_endr_show_flag,
             c_contrl_attr,
             c_date_format,
             c_prod_no,
             c_screen_cname,
             c_endr_read_only_flag,
             c_font_event_func,
             c_status,
             c_valid_item_contrl_attr,
             c_calc_valid_flag,
             c_rule_lev,
             c_chnl_code,
             c_read_only_var,
             c_cvrg_no,
             c_duty_no,
             c_list_show_flag,
             c_edr_unique_flag,
             c_list_generate_flag,
	     c_version,
	     c_prod_id,
	     C_SHOW_IN_CTNT_FLAG,
	     c_visit_show_flag,
	     c_endr_visit_show_flag,
	     c_clnt_group)
            SELECT UUID() AS c_pk_id,
                   prod_screen_no,
                   c_elem_no,
                   c_contrl_type,
                   c_check_type,
                   c_must_intput_flag,
                   c_read_only_flag,
                   c_view_show_flag,
                   c_dflt_value,
                   c_min_value,
                   c_max_value,
                   c_precision,
                   DATE_FORMAT(SYSDATE(), 'yyyy-MM-dd hh24:mi:ss') AS d_crtr_time,
                   DATE_FORMAT(SYSDATE(), 'yyyy-MM-dd hh24:mi:ss') AS d_uptr_time,
                   '001' AS c_crtr_code,
                   '001' AS c_uptr_code,
                   c_comp_code,
                   c_code_list_name,
                   n_string_length,
                   c_clk_event_func,
                   n_elem_show_seq,
                   c_elem_cname,
                   c_elem_ename,
                   c_rel_field_name,
                   c_rel_table_name,
                   c_endr_show_flag,
                   c_contrl_attr,
                   c_date_format,
                   prod_no,
                   c_screen_cname,
                   c_endr_read_only_flag,
                   c_font_event_func,
                   c_status,
                   c_valid_item_contrl_attr,
                   c_calc_valid_flag,
                   c_rule_lev,
                   c_chnl_code,
                   c_read_only_var,
                   c_cvrg_no,
                   c_duty_no,
                   c_list_show_flag,
                   c_edr_unique_flag,
                   c_list_generate_flag,
                   prod_version,
                   prod_id,
                   C_SHOW_IN_CTNT_FLAG,
                   c_visit_show_flag,
                   c_endr_visit_show_flag,
                   c_clnt_group
              FROM tb_prod_screen_rel_elem b
             WHERE b.c_prod_no = prodCode
   AND b.c_comp_code = compCode
   AND  b.c_rel_field_name = fieldName
   ORDER BY n_elem_show_seq;
   SET done = 0;
    END LOOP read_loop;

	CLOSE cur_screenno;
	
END;

